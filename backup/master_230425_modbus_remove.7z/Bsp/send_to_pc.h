#ifndef _SEND_TO_PC_H_
#define _SEND_TO_PC_H_

#include "main.h"


extern void send_to_pc();
#endif
